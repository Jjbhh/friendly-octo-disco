package net.stark.swordguard;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

public final class SwordGuardPlugin extends JavaPlugin implements Listener {

    private static final int OFFHAND_SLOT = 40;

    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Set<Material> extra = EnumSet.noneOf(Material.class);

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String s : getConfig().getStringList("extra-items")) {
            Material m = Material.matchMaterial(s);
            if (m != null) extra.add(m);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        // Authoritative fallback: catches every way of ending up with two swords
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
    }

    private boolean isSword(ItemStack item) {
        if (item == null || item.getType().isAir()) return false;
        return Tag.ITEMS_SWORDS.isTagged(item.getType()) || extra.contains(item.getType());
    }

    // ─────────────── prevention ───────────────

    /** F key (swap hands): block if the result would be sword + sword. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("swordguard.bypass")) return;
        if (isSword(e.getMainHandItem()) && isSword(e.getOffHandItem())) {
            e.setCancelled(true);
            notify(p, "blocked");
        }
    }

    /** Inventory clicks that would put a sword into the offhand while a sword is held. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (p.hasPermission("swordguard.bypass")) return;

        PlayerInventory inv = p.getInventory();
        ItemStack main = inv.getItemInMainHand();
        ItemStack incoming = null;

        if (e.getClick() == ClickType.SWAP_OFFHAND) {
            // hover + F: hovered item goes to offhand
            incoming = e.getCurrentItem();
        } else if (e.getClickedInventory() == inv && e.getSlot() == OFFHAND_SLOT) {
            if (e.getClick() == ClickType.NUMBER_KEY) {
                int btn = e.getHotbarButton();
                if (btn == inv.getHeldItemSlot()) return; // main hand item itself moves away
                incoming = inv.getItem(btn);
            } else {
                incoming = e.getCursor();
            }
        }

        if (isSword(incoming) && isSword(main)) {
            e.setCancelled(true);
            notify(p, "blocked");
        }
    }

    // ─────────────── fallback ───────────────

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("swordguard.bypass")) continue;
            PlayerInventory inv = p.getInventory();
            if (isSword(inv.getItemInMainHand()) && isSword(inv.getItemInOffHand())) {
                returnOffhand(p, inv);
            }
        }
    }

    private void returnOffhand(Player p, PlayerInventory inv) {
        ItemStack off = inv.getItemInOffHand().clone();
        inv.setItemInOffHand(null);
        Map<Integer, ItemStack> left = inv.addItem(off);
        left.values().forEach(it -> p.getWorld().dropItemNaturally(p.getLocation(), it));
        notify(p, "returned");
    }

    private void notify(Player p, String key) {
        String msg = getConfig().getString("messages." + key, "");
        if (!msg.isEmpty()) p.sendActionBar(mm.deserialize(msg));
        if (getConfig().getBoolean("sound", true)) {
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.7f);
        }
    }
}
